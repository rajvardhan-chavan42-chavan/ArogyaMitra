let token = "";

// Event listener for AI Workout button
document.getElementById("getWorkout").addEventListener("click", async () => {
    if (!token) {
        alert("Please login first!");
        return;
    }
    const response = await fetch("http://127.0.0.1:8000/ai/generate", {
        headers: {
            "Authorization": `Bearer ${token}`
        }
    });
    const data = await response.json();
    document.getElementById("workoutResult").innerText = data.workout;
});

// Dummy login (replace with real login page later)
document.getElementById("loginBtn").addEventListener("click", async () => {
    const email = prompt("Enter email:");
    const password = prompt("Enter password:");

    const response = await fetch("http://127.0.0.1:8000/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    const data = await response.json();
    if (data.access_token) {
        token = data.access_token;
        alert("Login successful!");
    } else {
        alert("Login failed!");
    }
});

// Dummy register (replace with real register page later)
document.getElementById("registerBtn").addEventListener("click", async () => {
    const name = prompt("Enter name:");
    const email = prompt("Enter email:");
    const age = prompt("Enter age:");
    const password = prompt("Enter password:");

    const response = await fetch("http://127.0.0.1:8000/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, age, password })
    });

    const data = await response.json();
    alert(data.msg);
});